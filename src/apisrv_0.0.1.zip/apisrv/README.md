# 晚餐拉霸 Restful API
## Build

```
yarn install (or npm install)
```

You need to edit mysql config file in .env

## Run

```
// build with webpack
yarn build

// run with nodemon
yarn start
```

## API Doc
No, not yet.
